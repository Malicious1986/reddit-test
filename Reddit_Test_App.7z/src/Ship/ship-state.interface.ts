export interface IShipState {
    size: number;
    name: string;
    damagedCount: number;
    isDead: boolean;
}