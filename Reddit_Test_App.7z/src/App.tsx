import React from 'react';
import './App.css';
import Field from './Field/field.component';

function App() {
  return (
    <div className="App">
      <Field />
    </div>
  );
}

export default App;
